let { MessageEmbed, EmbedBuilder } = require('discord.js');
let client = require('../../index');
let Bal = require("../../Schema/balance.js");
let { ChannelDonationLog, ChannelSaweriaLog, ChannelTrakteerLog } = require("../../config/config.json");
let { WL, DL, BGL } = require("../../config/configEmoji.json");

module.exports = {
    name: "Catch Of Donation Embeds"
};

client.on("messageCreate", async (message) => {
    if (message.channel.id === ChannelSaweriaLog) {
        if (message.embeds.length > 0) {
            let description = message.embeds[0].title;
            let footer = message.embeds[0].description;
            let Deposito = description.match(/Jumlah (.*)/);

            if (Deposito && footer) {
                let growIds = footer.toLowerCase();
                let depo = Deposito[1].replace(/\./g, '');
                console.log(depo);

                let wallet1 = await Bal.findOne({ GrowID: growIds })
                    .then((d) => {
                        return d;
                    });

                try {
                    if (!wallet1) return message.reply(`User **${footer}** Not Register In Database`);

                    await Bal.updateOne(
                        { GrowID: growIds },
                        { $inc: { Rupiah: depo, DpRupiah: depo } }
                    );

                    let wallets = await Bal.findOne({ GrowID: growIds })
                        .then((d) => {
                            return d.Rupiah;
                        });

                    let recev = new Intl.NumberFormat().format(wallets);
                    let userars = await client.users.fetch(wallet1.DiscordID);
                    let embed = new EmbedBuilder()
                        .setDescription(`**${userars.username}'s** Donate Rp.**${new Intl.NumberFormat().format(depo)}** Your Balance Is Rp.**${recev}**`);

                    userars.send({ embeds: [embed] });
                    await message.reply(`Successfully Adding Rp.**${new Intl.NumberFormat().format(depo)}** to **${footer}**\nYour New Balance Is Rp.**${recev}**`);
                } catch (error) {
                    console.error("erorr", error);
                }
            }
        }
    }
    if (message.channel.id === ChannelTrakteerLog) {
        if (message.embeds.length > 0) {
            let description = message.embeds[0].title;
            let footer = message.embeds[0].description;
            let Deposit = description.match(/Trakteer (\d+)/);

            if (Deposit && footer) {
                let growIds = footer.toLowerCase();
                let depos = parseInt(Deposit[1]);
                let depo = depos * 1000;

                let wallet1 = await Bal.findOne({ GrowID: growIds })
                    .then((d) => {
                        return d;
                    });

                try {
                    if (!wallet1) return message.reply(`User **${footer}** Not Register In Database`);

                    await Bal.updateOne(
                        { GrowID: growIds },
                        { $inc: { Rupiah: depo, DpRupiah: depo } }
                    );

                    let wallets = await Bal.findOne({ GrowID: growIds })
                        .then((d) => {
                            return d.Rupiah;
                        });

                    let userars = await client.users.fetch(wallet1.DiscordID);
                    let embed = new EmbedBuilder()
                        .setDescription(`**${userars.username}'s** Donate Rp.**${new Intl.NumberFormat().format(depo)}** Your Balance Is Rp.**${new Intl.NumberFormat().format(wallets)}**`);

                    userars.send({ embeds: [embed] });
                    await message.reply(`Successfully Adding Rp.**${new Intl.NumberFormat().format(depo)}** to **${footer}**\nYour New Balance Is Rp.**${new Intl.NumberFormat().format(wallets)}**`);
                } catch (error) {
                    console.error("erorr", error);
                }
            }
        }
    }
    if (message.channel.id === ChannelDonationLog) {
        if (message.embeds.length > 0) {
            let footer = message.embeds[0].description;
            let GrowIDs = footer.match(/GrowID: (\w+)/);
            let Deposita = footer.match(/Amount: (\d+) (\w+)/);

            if (GrowIDs && Deposita) {
                let growId = GrowIDs[1];
                let growIds = growId.toLowerCase();
                let depo = parseInt(Deposita[1]);
                let item = Deposita[2];

                let itemvalue = {
                    "WorldLock": 1,
                    "DiamondLock": 100,
                    "BlueGemLock": 10000,
                };

                let Lko = {
                    "WorldLock": WL,
                    "DiamondLock": DL,
                    "BlueGemLock": BGL,
                }

                let wallet1 = await Bal.findOne({ GrowID: growIds })
                    .then((d) => {
                        return d;
                    });

                try {
                    if (!wallet1) return message.reply("User Not Register In Database");
                    if (!itemvalue[item]) return message.reply("Unknown Item Name");

                    await Bal.updateOne(
                        { GrowID: growIds },
                        { $inc: { Balance: depo * itemvalue[item], Deposit: depo * itemvalue[item] } }
                    );

                    let wallets = await Bal.findOne({ GrowID: growIds })
                        .then((d) => {
                            return d.Balance;
                        });

                    let userars = await client.users.fetch(wallet1.DiscordID);
                    userars.send(`Successfully Adding **${depo} ${Lko[item]}** to **${growId}**\nYour New Balance Is **${wallets}** ${WL}`);
                    await message.reply(`Successfully Adding **${depo} ${Lko[item]}** to **${growId}**\nYour New Balance Is **${wallets}** ${WL}`);
                } catch (error) {
                    console.error("erorr", error);
                }
            }
        }
    }
})