let { Owner } = require("../../config/config.json");
let {
    InteractionType,
    ButtonStyle,
    ActionRowBuilder,
    EmbedBuilder,
    ButtonBuilder,
} = require("discord.js");
let Bal = require("../../Schema/balance.js");
let shop = require("../../Schema/shop.js");
let list = require("../../Schema/list.js");
let Price = require("../../Schema/price.js");
let order = require("../../Schema/order.js");
let { MessageEmbed } = require("discord.js");
let ctesti = require("../../Schema/AllSettingChannel.js");
let client = require('../../index.js');
let { Dolar, Crown, Yes, Loading, WL, ARROW, COLOR, imageUrl } = require("../../config/configEmoji.json");

module.exports = {
    name: "Buying Item Of Menu"
};

client.on("interactionCreate", async (interaction) => {
    if (interaction.customId === "sammuh") {
        if (interaction.type !== InteractionType.ModalSubmit) return;
        let howmuch = interaction.fields.getTextInputValue("summah");
        let item = interaction.fields.getTextInputValue("kontol");
        let typas = interaction.fields.getTextInputValue("type");
        let typa = typas.toLowerCase();
        let user = interaction.user;
        let userars = await client.users.fetch(Owner);
        let member = interaction.guild.members.cache.get(user.id);

        let chaneltesti = await ctesti
            .findOne({})
            .then((d) => {
                return d.ChanelTesti;
            })
            .catch((e) => console.error(e));

        if (!chaneltesti) return interaction.reply({
            content: "Tag Owner For Setting Channel Testimoni Now!!!!",
            ephemeral: true,
        });

        let getCode = await list
            .findOne({ code: item })
            .then((res) => {
                return res;
            })
            .catch(console.error);

        if (!getCode) return interaction.reply({
            content: "Code Not Found",
            ephemeral: true
        });

        if (howmuch < 1) return interaction.reply({
            content: "Use a Positif Number!",
            ephemeral: true,
        });

        if (isNaN(howmuch)) return interaction.reply({
            content: "Only Use Number For Amount",
            ephemeral: true,
        });

        let row6050 = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setLabel("Set GrowID")
                .setStyle(ButtonStyle.Secondary)
                .setEmoji("<:Bot:1170169208273903677>")
                .setCustomId("growid23")
        );

        let getBal = await Bal.findOne({ DiscordID: user.id })
            .then((d) => {
                return d;
            })
            .catch((e) => console.error(e));

        if (!getBal) return interaction.reply({
            content: "Register First Before Using This Button!",
            components: [row6050],
            ephemeral: true,
        });

        let pricao = await Price.findOne({ code: item })
            .then((d) => {
                return d;
            })
            .catch((e) => console.error(e));

        let data = await shop
            .find({ code: item })
            .then((res) => {
                return res;
            })
            .catch(console.error);

        if (data.length == 0) return interaction.reply({
            content: "No Stock Yet",
            ephemeral: true
        });

        if (Number(data.length) < Number(howmuch)) return interaction.reply({
            content: "Not That Much Stock",
            ephemeral: true
        });

        if (!pricao) return interaction.reply({
            content: `Tag Owner To Set Price For **${item}**`,
            ephemeral: true
        });

        let price = pricao.price;
        let Rupiah = pricao.Rupiah;
        let wallet = getBal.Balance;
        let walletRupiah = getBal.Rupiah;
        let oprice = Number(price) * Number(howmuch);
        let prico = Number(Rupiah) * Number(howmuch);
        let ch = interaction.guild.channels.cache.get(chaneltesti);

        if (typa === "lock" || typa === "cash") {
            if (typa === "cash") {
                if (!Rupiah) return interaction.reply({
                    content: `Tag Owner For Set To Rupiah For **${item}**`,
                    ephemeral: true
                });

                if (walletRupiah < prico) return interaction.reply({
                    content: "Ur Money Is Less, The Price Is Rp." + new Intl.NumberFormat().format(prico),
                    ephemeral: true,
                });
            }

            if (typa === "lock") {
                if (wallet < oprice) return interaction.reply({
                    content: "Ur Money Is Less, The Price Is " + oprice,
                    ephemeral: true,
                });
            }
        } else {
            await interaction.reply({
                content: `For Payment Only Put **Cash** Or **Lock**`,
                ephemeral: true
            });
            return;
        }

        let doneBuy = new EmbedBuilder()
            .setTitle(`${Crown} Purchase Item Successfull ${Crown}`)
            .setDescription(
                `${ARROW} Buyer: <@${interaction.user.id}>\n` +
                `${ARROW} Product: **${getCode.name}**\n` +
                `${ARROW} Total: **${howmuch}**\n` +
                `${ARROW} Total Price: **${oprice}** ${WL}`
            )
            .setTimestamp()
            .setColor(COLOR)
            .setImage(imageUrl)
            .setFooter({
                text: `No Reps , No Waranty`,
                iconURL: client.user.displayAvatarURL({ dynamic: true }),
            });

        let doneBuys = new EmbedBuilder()
            .setTitle(`${Crown} Purchase Item Successfull ${Crown}`)
            .setDescription(
                `${ARROW} Buyer: <@${interaction.user.id}>\n` +
                `${ARROW} Product: **${getCode.name}**\n` +
                `${ARROW} Total: **${howmuch}**\n` +
                `${ARROW} Total Price: Rp.**${new Intl.NumberFormat().format(prico)}** ${Dolar}`
            )
            .setTimestamp()
            .setColor(COLOR)
            .setImage(imageUrl)
            .setFooter({
                text: `No Reps , No Waranty`,
                iconURL: client.user.displayAvatarURL({ dynamic: true }),
            });

        let orderN = await order
            .findOneAndUpdate(
                {},
                { $inc: { Order: 1 } },
                { upsert: true, new: true }
            )
            .then((d) => {
                return d?.Order;
            })
            .catch(console.error);
        if (!orderN) orderN = 1;

        let testi = new EmbedBuilder()
            .setTitle("#Order Number: " + orderN)
            .setDescription(
                ARROW +
                "Buyer: **<@" +
                user.id +
                ">**\n" +
                ARROW +
                "Produk: **" +
                (getCode.name) +
                "**\n" +
                ARROW +
                "Jumlah: **" +
                howmuch +
                "**\n" +
                ARROW +
                "Total Price: **" +
                oprice +
                " " +
                WL +
                " **\n**Thanks For Purchasing Our Product**"
            )
            .setColor(COLOR)
            .setTimestamp()
            .setImage(imageUrl);

        let testis = new EmbedBuilder()
            .setTitle("#Order Number: " + orderN)
            .setDescription(
                ARROW +
                "Buyer: **<@" +
                user.id +
                ">**\n" +
                ARROW +
                "Produk: **" +
                (getCode.name) +
                "**\n" +
                ARROW +
                "Jumlah: **" +
                howmuch +
                "**\n" +
                ARROW +
                "Total Price: **Rp." +
                new Intl.NumberFormat().format(prico) +
                " " +
                Dolar +
                " **\n**Thanks For Purchasing Our Product**"
            )
            .setColor(COLOR)
            .setTimestamp()
            .setImage(imageUrl);

        let sending = "";
        await interaction.reply({
            content: `**Processing Your Order ${Loading}**`,
            ephemeral: true,
        });
        try {
            if (!getCode.type.includes("script")) {
                for (let i = 0; i < howmuch; i++) {
                    let send = await shop
                        .findOneAndDelete({ code: item })
                        .then((res) => {
                            return res;
                        })
                        .catch(console.error);
                    sending += send.data + "\n";
                }
            } else {
                let send = await shop
                    .findOne({ code: item })
                    .then((res) => {
                        return res;
                    })
                    .catch(console.error);
                sending += send.data;
            }
            if (typa === "lock") {
                await Bal.updateOne(
                    { DiscordID: user.id },
                    { $inc: { Balance: -Number(oprice) } }
                );

                user.send({
                    content: `This Is ${interaction.user.username} Order`,
                    files: [
                        {
                            attachment: Buffer.from(sending),
                            name: `${interaction.user.username} Order.txt`,
                        },
                    ],
                    embeds: [doneBuy],
                });
                await ch.send({ embeds: [testi] });
            } else if (typa === "cash") {
                await Bal.updateOne(
                    { DiscordID: user.id },
                    { $inc: { Rupiah: -Number(prico) } }
                );

                user.send({
                    content: `This Is ${interaction.user.username} Order`,
                    files: [
                        {
                            attachment: Buffer.from(sending),
                            name: `${interaction.user.username} Order.txt`,
                        },
                    ],
                    embeds: [doneBuys],
                });
                await ch.send({ embeds: [testis] });
            }

            if (!member.roles.cache.some((r) => r.id == getCode.role)) {
                member.roles.add(getCode.role);
            }

            await interaction.followUp({
                content: `**Check Your Direct Message For Your Order! ${Yes}**`,
                ephemeral: true
            });

            userars.send({
                content: "This Is <@" + interaction.user.id + "> Order",
                files: [
                    {
                        attachment: Buffer.from(sending),
                        name: `${interaction.user.username} Order.txt`,
                    },
                ],
            });
        } catch (erorr) {
            interaction.followUp({
                content: "Did you turn off DM? if Yes u can dm Owner, if he is good maybe will be given your order :):",
                ephemeral: true,
            });

            userars.send({
                content: "This Is <@" + interaction.user.id + "> Order",
                files: [
                    {
                        attachment: Buffer.from(sending),
                        name: `${interaction.user.username} Order.txt`,
                    },
                ],
            });
        }
    }
})